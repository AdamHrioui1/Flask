from flask import Flask, render_template, request
app = Flask(__name__)

global messages
messages = []

@app.route('/')
@app.route('/home')
def index():
    return render_template("home.html", title="home")

@app.route('/about')
def about():
    return render_template("about.html", title="about")

@app.route('/contact', methods=["POST", "GET"])
def contact():
    if request.method == "POST":
        messages.append({"id": len(messages), "title": request.form["title"], "message": request.form["message"]})
        print(messages)
    return render_template("contact.html", title="contact")

@app.route('/articles')
def articles():
    return render_template("articles.html", title="Articles")

@app.route('/message', methods=["GET"])
def message():
    if request.method == "GET":
        return render_template("message.html", title="message", msgs=messages)
    return render_template("message.html", title="message")


if __name__ == "__main__":
    app.run(debug=True, port=5003)