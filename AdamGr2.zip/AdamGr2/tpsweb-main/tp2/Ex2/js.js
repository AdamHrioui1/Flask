const box = document.getElementById("box");
var i=0;
for(i=0; i<31; i++){
    console.log(i)
}